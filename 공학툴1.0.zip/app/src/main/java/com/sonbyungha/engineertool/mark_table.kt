package com.sonbyungha.engineertool

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class mark_table : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.mark_table_layout)
    }
}