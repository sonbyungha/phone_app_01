package com.sonbyungha.engineertool

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class circuit_table1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.circuit_table1)
    }
}